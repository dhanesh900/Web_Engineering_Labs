import './App.css';
import FormComp from './FormComp';
import Signup from './Signup';

function App() {
  return (
    <div>
      {/* <FormComp /> */}
      <Signup/>
    </div>
  );
}

export default App;
